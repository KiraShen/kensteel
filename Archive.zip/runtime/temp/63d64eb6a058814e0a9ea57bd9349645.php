<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:69:"/Users/apple/Documents/www/cms/application/shares/view/info.type.html";i:1529679068;s:72:"/Users/apple/Documents/www/cms/application/extra/view/admin.content.html";i:1497930894;}*/ ?>
<div class="ibox">
    
    <?php if(isset($title)): ?>
    <div class="ibox-title">
        <h5><?php echo $title; ?></h5>
        
<div class="nowrap pull-right" style="margin-top:10px">
    <a href='<?php echo url("$classuri/out"); ?>' data-title="添加分类" class='layui-btn layui-btn-small'>
    <i class='glyphicon glyphicon-share-alt'></i> 导出数据
    </a>
    <!-- <button data-modal='<?php echo url("$classuri/add_cate"); ?>' data-title="添加分类" class='layui-btn layui-btn-small'>
    <i class='fa fa-plus'></i> 添加分类
    </button>
    <button data-update data-field='delete' data-action='<?php echo url("$classuri/del_cate"); ?>' class='layui-btn layui-btn-small layui-btn-danger'><i class='fa fa-remove'></i> 删除分类
    </button> -->
</div>

    </div>
    <?php endif; ?>
    <div class="ibox-content fadeInUp animated">
        <?php if(isset($alert)): ?>
        <div class="alert alert-<?php echo $alert['type']; ?> alert-dismissible" role="alert" style="border-radius:0">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            <?php if(isset($alert['title'])): ?><p style="font-size:18px;padding-bottom:10px"><?php echo $alert['title']; ?></p><?php endif; if(isset($alert['content'])): ?><p style="font-size:14px"><?php echo $alert['content']; ?></p><?php endif; ?>
        </div>
        <?php endif; ?>
        

<form onsubmit="return false;" data-auto="" method="POST">
    <input type="hidden" value="resort" name="action"/>
    <table class="table table-hover">
        <thead>
        <tr>
            <th class='list-table-check-td'>
                <input data-none-auto="" data-check-target='.list-check-box' type='checkbox'/>
            </th>
            <th>id</th>
            <th>分类名称</th>
            <th>套餐金额</th>
            <th>股票数量</th>
            <th class='text-center'>状态</th>
            <th class='text-center'>操作</th>
        </tr>
        </thead>
        <tbody>
        <?php foreach($list as $key=>$vo): ?>
        <tr>
            <td class='list-table-check-td'>
                <input class="list-check-box" value='<?php echo $vo['id']; ?>' type='checkbox'/>
            </td>
            <td><?php echo $vo['id']; ?></td>
            <td><?php echo (isset($vo['type_name']) && ($vo['type_name'] !== '')?$vo['type_name']:""); ?></td>
            <td><?php echo (isset($vo['money']) && ($vo['money'] !== '')?$vo['money']:""); ?></td>
            <td><?php echo (isset($vo['shares']) && ($vo['shares'] !== '')?$vo['shares']:""); ?></td>
            <td class='text-center'>
                <?php if($vo['status'] == 0): ?>
                <span>已禁用</span>
                <?php elseif($vo['status'] == 1): ?>
                <span style="color:#090">使用中</span>
                <?php endif; ?>
            </td>
            <td class='text-center nowrap'>
                <?php if(auth("$classuri/edit_cate")): ?>
                <span class="text-explode">|</span>
                <a data-modal='<?php echo url("$classuri/edit_cate"); ?>?id=<?php echo $vo['id']; ?>' href="javascript:void(0)">编辑</a>
                <?php endif; if(auth("$classuri/del_cate")): ?><!-- 
                <span class="text-explode">|</span>
                <a data-update="<?php echo $vo['id']; ?>" data-field='del' data-action='<?php echo url("$classuri/del_cate"); ?>'
                   href="javascript:void(0)">删除</a> -->
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php if(isset($page)): ?><p><?php echo $page; ?></p><?php endif; ?>
</form>

    </div>
    
</div>