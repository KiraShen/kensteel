<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:76:"/Users/apple/Documents/www/cms/application/shares/view/agent.agent_form.html";i:1529651244;}*/ ?>
<form class="layui-form layui-box" style='padding:25px 30px 20px 0' action="__SELF__" data-auto="true" method="post">

    

    <div class="layui-form-item">
        <label class="layui-form-label">代理区域(例如:浙江杭州)</label>
        <div class="layui-input-block">
            <input type="text" name="area" value='<?php echo (isset($vo['area']) && ($vo['area'] !== '')?$vo['area']:""); ?>' required="required" title="代理区域" placeholder="代理区域" class="layui-input">
        </div>
    </div>

    <div class="layui-form-item">
        <label class="layui-form-label">代理名称(子公司名称)</label>
        <div class="layui-input-block">
            <input type="text" name="agent_name" value='<?php echo (isset($vo['agent_name']) && ($vo['agent_name'] !== '')?$vo['agent_name']:""); ?>' required="required" title="代理名称" placeholder="代理名称" class="layui-input">
        </div>
    </div>
    
    <div class="layui-form-item">
     <label class="layui-form-label">法人姓名</label>
        <div class="layui-input-block">
            <input type="text" name="person" value='<?php echo (isset($vo['person']) && ($vo['person'] !== '')?$vo['person']:""); ?>' required="required" title="法人姓名" placeholder="法人姓名" class="layui-input">
        </div>
    </div>

    <div class="layui-form-item">
     <label class="layui-form-label">法人手机</label>
        <div class="layui-input-block">
            <input type="text" name="phone" value='<?php echo (isset($vo['phone']) && ($vo['phone'] !== '')?$vo['phone']:""); ?>' required="number" title="法人手机" placeholder="法人手机" class="layui-input">
        </div>
    </div>

    <div class="layui-form-item">
     <label class="layui-form-label">代理用户名(例如:'浙江沸达州'->'zjfdz')</label>
        <div class="layui-input-block">
            <input type="text" name="agentname" value='<?php echo (isset($vo['agentname']) && ($vo['agentname'] !== '')?$vo['agentname']:""); ?>' required="required" title="代理用户名" placeholder="代理用户名" class="layui-input">
        </div>
    </div>

    <div class="layui-form-item">
     <label class="layui-form-label">密码(请设置为法人手机后六位)</label>
        <div class="layui-input-block">
            <input type="text" name="password" value='<?php echo (isset($vo['password']) && ($vo['password'] !== '')?$vo['password']:""); ?>' required="required" title="密码" placeholder="密码" class="layui-input">
        </div>
    </div>

    <div class="hr-line-dashed"></div>

    <div class="layui-form-item text-center">
        <?php if(isset($vo['id'])): ?><input type='hidden' value='<?php echo $vo['id']; ?>' name='id'/><?php endif; ?>
        <button class="layui-btn" type='submit'>保存数据</button>
        <button class="layui-btn layui-btn-danger" type='button' data-confirm="确定要取消编辑吗？" data-close>取消编辑</button>
    </div>


</form>
