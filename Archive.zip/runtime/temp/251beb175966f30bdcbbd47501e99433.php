<?php if (!defined('THINK_PATH')) exit(); /*a:5:{s:75:"/Users/apple/Documents/www/cms/application/index/view/franchisee.index.html";i:1529678940;s:72:"/Users/apple/Documents/www/cms/application/index/view/public.header.html";i:1529811007;s:69:"/Users/apple/Documents/www/cms/application/index/view/public.nav.html";i:1529650174;s:78:"/Users/apple/Documents/www/cms/application/index/view/public.mobileheader.html";i:1529811321;s:72:"/Users/apple/Documents/www/cms/application/index/view/public.footer.html";i:1529991847;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Kensteel V1.0</title>

  <link rel="stylesheet" href="http://cdn.amazeui.org/amazeui/1.0.1/js/amazeui.min.js" />
  <link rel="stylesheet" href="__KUI__/css/amazeui.css" />
  <link rel="stylesheet" href="__KUI__/css/common.min.css" />
  <link rel="stylesheet" href="__KUI__/css/index.min.css" />
  <link rel="stylesheet" href="__KUI__/css/contact.min.css" />
</head>
<body>
  <div class="layout">
    <!--===========layout-header================-->
    <div class="layout-header am-hide-sm-only">
      <!--topbar start-->
<!--       <div class="topbar">
        <div class="container">
          <div class="am-g">
            <div class="am-u-md-3">
              <div class="topbar-left">
                <i class="am-icon-globe"></i>
                <div class="am-dropdown" data-am-dropdown>
                  <button class="am-btn am-btn-primary am-dropdown-toggle" data-am-dropdown-toggle>Language <span class="am-icon-caret-down"></span></button>
                  <ul class="am-dropdown-content">
                    <li><a href="#">English</a></li>
                    <li class="am-divider"></li>
                    <li><a href="#">Chinese</a></li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="am-u-md-9">
              <div class="topbar-right am-text-right am-fr">
                Follow us
                <i class="am-icon-facebook"></i>
                <i class="am-icon-twitter"></i>
                <i class="am-icon-google-plus"></i>
                <i class="am-icon-pinterest"></i>
                <i class="am-icon-instagram"></i>
                <i class="am-icon-linkedin"></i>
                <i class="am-icon-youtube-play"></i>
                <i class="am-icon-rss"></i>
                <a href="html/login.html">登录</a>
                <a href="html/register.html">注册</a>
              </div>
            </div>
          </div>
        </div>
      </div> -->
      <!--topbar end-->


      <div class="header-box" data-am-sticky>
        <!--header start-->
          <div class="container">
            <div class="header">
              <div class="am-g">
                <div class="am-u-lg-2 am-u-sm-12">
                  <div class="logo">
                    <a href=""><img src="__KUI__/images/logo.png" alt="" /></a>
                  </div>
                </div>
                <div class="am-u-md-10">
                  <div class="header-right am-fr">
                    <div class="header-contact">
                      <!-- <div class="header_contacts--item">
                                            <div class="contact_mini">
                                                <i style="color:#7c6aa6" class="contact-icon am-icon-phone"></i>
                                                <strong>0 (855) 233-5385</strong>
                                                <span>周一~周五, 8:00 - 20:00</span>
                                            </div>
                                        </div> -->
                      <div class="header_contacts--item">
                                            <div class="contact_mini">
                                                <i style="color:#7c6aa6" class="contact-icon am-icon-envelope-o"></i>
                                                <strong><?php echo $web_email['0']['value']; ?></strong>
                                                <span>随时欢迎您的来信！</span>
                                            </div>
                                        </div>
                      <div class="header_contacts--item">
                                            <div class="contact_mini">
                                                <i style="color:#7c6aa6" class="contact-icon am-icon-map-marker"></i>
                                                <strong><?php echo $web_company['0']['value']; ?></strong>
                                                <span><?php echo $web_address['0']['value']; ?></span>
                                            </div>
                                        </div>
                    </div>
                    <span style="color: black">当前登录：</span>
                      <span style="color: red"><?php echo (isset($agent_name) && ($agent_name !== '')?$agent_name:"无"); ?>&nbsp;&nbsp;</span>
                      <?php if($login_status == 1): ?>
                    <a href="<?php echo $web_url['0']['value']; ?>/logout.html" class="contact-btn">
                      <!-- <button type="button" class="am-btn am-btn-secondary am-radius"> -->
                      退出
                      <!-- </button> -->
                    </a>
                      <?php endif; if($login_status == 0): ?>
                    <a href="<?php echo $web_url['0']['value']; ?>/login.html" class="contact-btn">
                      <!-- <button type="button" class="am-btn am-btn-secondary am-radius"> -->
                      登录
                      <!-- </button> -->
                    </a>
                      <?php endif; ?>
                  </div>
                </div>
              </div>
            </div>
          </div>
        <!--header end-->

        <!--nav start-->
        <div class="nav-contain">
          <div class="nav-inner">
            <!-- <ul class="am-nav am-nav-pills am-nav-justify"> -->
            <ul class="am-nav am-nav-pills">

            <?php if(is_array($nav_list) || $nav_list instanceof \think\Collection || $nav_list instanceof \think\Paginator): $i = 0; $__LIST__ = $nav_list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$nav): $mod = ($i % 2 );++$i;?>
                <li><a href="<?php echo $nav['url']; ?>" title="<?php echo $nav['title']; ?>"><?php echo $nav['title']; ?></a></li>
            <?php endforeach; endif; else: echo "" ;endif; ?>
            <!-- 
              <li "><a href="./index.html">首页</a></li>
              <li><a href="franchisee.html">沸达州加盟</a></li>  -->
              <!-- <li>
                <a href="#">产品中心</a>
                <ul class="sub-menu">
                  <li class="menu-item"><a href="html/product1.html">产品展示1</a></li>
                  <li class="menu-item"><a href="html/product2.html">产品展示2</a></li>
                  <li class="menu-item"><a href="html/product3.html">产品展示3</a></li>
                </ul>
              </li>
              <li><a href="html/example.html">客户案例</a></li>
              <li><a href="html/solution.html">解决方案</a></li>
              <li>
                <a href="html/news.html">新闻中心</a>
                <ul class="sub-menu">
                  <li class="menu-item"><a href="html/news-content.html">公司动态</a></li>
                  <li class="menu-item"><a href="html/404-dark.html">行业动态</a></li>
                  <li class="menu-item"><a href="html/404-light.html">精彩专题</a></li>
                </ul>
              </li>-->
              <!-- 
              <li><a href="html/about.html">关于我们</a></li>
              <li><a href="html/join.html">加入我们</a></li>
              <li><a href="html/contact.html">联系我们</a></li>  -->
            </ul>
          </div>
        </div>
        <!--nav end-->
      </div>
    </div>

<script>
    var curr_url = window.location.href;  //获取当前URL
    $('#menu li a').each(function(i,n){  //循环导航的a标签
        var href = $(this).attr('href'); //a标签中的href链接
        if(href == curr_url){  //如果当前URL,和a标签中的href相等。
            $(this).addClass('active');  //那么就给这个a标签增加home_page类。
        }
    })
</script>
    <!--mobile header start-->
    <div class="m-header">
      <div class="am-g am-show-sm-only">
        <div class="am-u-sm-2">
          <div class="menu-bars">
            <a href="#doc-oc-demo1" data-am-offcanvas="{effect: 'push'}"><i class="am-menu-toggle-icon am-icon-bars"></i></a>
            <!-- 侧边栏内容 -->
            <nav data-am-widget="menu" class="am-menu  am-menu-offcanvas1" data-am-menu-offcanvas >
            <a href="javascript: void(0)" class="am-menu-toggle"></a>

            <div class="am-offcanvas" >
              <div class="am-offcanvas-bar">
              <ul class="am-menu-nav am-avg-sm-1">
                <?php if(is_array($nav_list) || $nav_list instanceof \think\Collection || $nav_list instanceof \think\Paginator): $i = 0; $__LIST__ = $nav_list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$nav): $mod = ($i % 2 );++$i;?>
                  <li><a href="<?php echo $nav['url']; ?>" title="<?php echo $nav['title']; ?>"><?php echo $nav['title']; ?></a></li>
                <?php endforeach; endif; else: echo "" ;endif; ?>
                
                   <!-- <li class="am-parent">
                    <a href="#" class="" >产品中心</a>
                      <ul class="am-menu-sub am-collapse ">
                          <li class="">
                            <a href="html/product1.html" class="" >产品展示1</a>
                          </li>
                          <li class="">
                            <a href="html/product2.html" class="" >产品展示2</a>
                          </li>
                          <li class="">
                            <a href="html/product3.html" class="" >产品展示3</a>
                          </li>
                      </ul>
                  </li>
                  <li class=""><a href="html/example.html" class="" >客户案例</a></li>
                  <li class=""><a href="html/solution.html" class="" >解决方案</a></li>
                  <li class="am-parent">
                    <a href="html/news.html" class="" >新闻中心</a>
                      <ul class="am-menu-sub am-collapse  ">
                          <li class="">
                            <a href="html/news-content.html" class="" >公司动态</a>
                          </li>
                          <li class="">
                            <a href="html/404-dark.html" class="" >行业动态</a>
                          </li>
                          <li class="">
                            <a href="html/404-light.html" class="" >精彩专题</a>
                          </li> 
                      </ul>
                  </li>
                  <li class=""><a href="html/about.html" class="" >关于我们</a></li>
                  <li class=""><a href="html/join.html" class="" >加入我们</a></li>
                  <li class=""><a href="html/contact.html" class="" >联系我们</a></li>
                  <li class="am-parent">
                    <a href="" class="nav-icon nav-icon-globe" >Language</a>
                      <ul class="am-menu-sub am-collapse  ">
                          <li>
                            <a href="#" >English</a>
                          </li>
                          <li class="">
                            <a href="#" >Chinese</a>
                          </li>
                      </ul>
                  </li>
                  <li class="nav-share-contain">
                    <div class="nav-share-links">
                      <i class="am-icon-facebook"></i>
                      <i class="am-icon-twitter"></i>
                      <i class="am-icon-google-plus"></i>
                      <i class="am-icon-pinterest"></i>
                      <i class="am-icon-instagram"></i>
                      <i class="am-icon-linkedin"></i>
                      <i class="am-icon-youtube-play"></i>
                      <i class="am-icon-rss"></i>
                    </div>
                  </li> -->
                  <?php if($login_status == 0): ?>
                  <li class=""><a href="<?php echo $web_url['0']['value']; ?>/login.html" class="" >登录</a></li>
                  <?php endif; if($login_status == 1): ?>
                  <li class=""><a href="<?php echo $web_url['0']['value']; ?>/logout.html" class="" >退出</a></li>
                  <?php endif; ?>
                  
                  <li class="" style="color: black">当前登录:<span style="color: red"><?php echo (isset($agent_name) && ($agent_name !== '')?$agent_name:"无"); ?></span></li>
                  <!-- <li class=""><a href="html/register.html" class="" >注册</a></li> -->

              </ul>

              </div>
            </div>
          </nav>

          </div>
        </div>
        <div class="am-u-sm-5 am-u-end">
          <div class="m-logo">
            <a href=""><img src="__KUI__/images/logo.png" alt=""></a>
          </div>
        </div>
      </div>
    <!--mobile header end-->
    </div>

    <!--===========layout-container================-->
  <!--   <div class="layout-container">
      <div class="page-header">
        <div class="am-container">
          <h1 class="page-header-title">Contact Us</h1>
        </div>
      </div>

      <div class="breadcrumb-box">
        <div class="am-container">
          <ol class="am-breadcrumb">
            <li><a href="../index.html">首页</a></li>
            <li class="am-active">联系我们</li>
          </ol>
        </div>
      </div>
    </div> -->

    <div class="section">
      <div class="container">
        <div class="section--header" style="margin: -50px">
					<h2 class="section--title">沸达州加盟 FELLAZO FRANCHISEE</h2>
					<!-- <p class="section--description">
            云适配致力于为企业提供全球最先进的移动化技术帮助企业最高效安全实现生产力提升<br/>
              One Web，Any Device
					</p> -->
				</div>

        <div class="section-container">
          <div class="am-g">
           

            <!--contact-right start-->
              <div class="am-u-md-12">
                <div class="contact-form">
                  <!-- <h3 class="contact-form_title">请写下你的加盟信息：</h3> -->
                  <form action="http://127.0.0.1/info_post" class="am-form" id="doc-vld-msg" method="POST">
                    <fieldset>
                    <legend>请写下你的加盟信息：</legend>
                    <div class="am-g">
                      <div class="am-u-md-3">
                        <div class="am-form-group" style="background: #fcfcfc;">
                          <select id="doc-select-1" style="width: 100%;font-size: 16px;line-height: 20px;padding: 15px 20px;border-radius: 3px;color: #262626;border: 2px solid #e9e9e9;" required name="tid">

                            <?php if(is_array($type_list) || $type_list instanceof \think\Collection || $type_list instanceof \think\Paginator): $i = 0; $__LIST__ = $type_list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$type): $mod = ($i % 2 );++$i;?>
                                <option value="<?php echo $type['id']; ?>"><?php echo $type['type_name']; ?></option>
                            <?php endforeach; endif; else: echo "" ;endif; ?>
                          </select>
                          <span class="am-form-caret"></span>
                        </div>
                      </div>
                      <div class="am-u-md-3">
                        <input type="text" class="" id="doc-ipt-last" placeholder="姓" name="last_name" required >
                      </div>
                      <div class="am-u-md-3">
                        <input type="text" class="" id="doc-ipt-first" placeholder="名" name="first_name" required>
                      </div>
                      <div class="am-u-md-3">
                        <input type="text" class="" id="doc-ipt-phone" placeholder="手机号" name="phone" pattern="^1[0-9]{10}$" required>
                      </div>
                    </div>

                    <div class="am-g">
                      <div class="am-u-md-6">
                        <input type="text" class="" id="doc-ipt-identy" placeholder="身份证号" name="code" pattern="^[1-9]\d{5}[1-9]\d{3}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}([0-9]|X)$" required >
                      </div>
                      <div class="am-u-md-6">
                        <input type="text" class="" id="doc-ipt-address" placeholder="身份证地址" name="address" required>
                      </div>
                    </div>
                    
                    <div class="am-g">
                      <div class="am-u-md-6">
                        <input type="number" class="" id="doc-ipt-banknum" placeholder="开户银行账户" name="banknum" required>
                      </div>
                      <div class="am-u-md-6">
                        <input type="text" class="" id="doc-ipt-bankinfo" placeholder="开户银行信息" name="bankinfo" required>
                      </div>
                    </div>

                    

                    <!-- <div class=am-g>
                      <div class="am-u-md-12">
                        <div class="am-form-group">
                          <textarea class="" rows="5" id="doc-ta-1" placeholder="写下你想说的..."></textarea>
                        </div>
                      </div>
                    </div>

                    <div class="am-g">
                      <div class="am-u-md-9">
                        <div class="am-form-group am-form-file">
                          <button type="button" class="am-btn am-btn-default am-btn-sm btn-change">
                            <i class="am-icon-cloud-upload"></i> 上传文件</button>
                          <input type="file" multiple>
                        </div>
                      </div>
                      <div class="am-u-md-3">
                        <p><button type="submit" class="am-btn am-btn-default btn-reguest am-fr btn-fl">提交</button></p>
                      </div>
                    </div> -->

                      <div class="am-u-md-12">
                        <p><button type="submit" class="am-btn am-btn-default btn-reguest am-fr btn-fl">提交</button></p>
                      </div>
                    </fieldset>
                  </form>
                </div>
              </div>
            <!--contact-right end-->
          </div>
        </div>
      </div>
    </div>
  </div>

  <!--===========layout-footer================-->
  <div class="layout-footer">
    <div class="footer">
      <div style="background-color:#383d61" class="footer--bg"></div>
      <div class="footer--inner">
        <div class="container">
          <div class="footer_main">
            <div class="am-g">
                <div class="footer_main--column">
                  <div class="footer_about" style="text-align: center;">
                      <p class="footer_about--text" style="margin-top: -50px">
                        <?php echo $web_company['0']['value']; ?><br>
                        <!-- 桐乡乌镇乐点网络软件开发有限公司<br> -->
                        <a href="http://www.miitbeian.gov.cn" style="color: #ffffff;" ><?php echo $web_icp['0']['value']; ?></a>
                      </p>

                    </div>
                </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <script src="__KUI__/js/jquery-2.1.0.js" charset="utf-8"></script>
  <script src="__KUI__/js/amazeui.js" charset="utf-8"></script>
  <script src="__KUI__/js/common.js" charset="utf-8"></script>
</body>

</html>
