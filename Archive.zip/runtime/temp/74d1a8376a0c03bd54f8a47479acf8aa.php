<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:72:"/Users/apple/Documents/www/cms/application/shares/view/account.form.html";i:1529895145;}*/ ?>
<form class="layui-form layui-box" style='padding:25px 30px 20px 0' action="__SELF__" data-auto="true" method="post">

    <div class="layui-form-item">
        <label class="layui-form-label">银行流水</label>
        <div class="layui-input-block">
            <input type="text" name="remark" value='<?php echo (isset($vo['remark']) && ($vo['remark'] !== '')?$vo['remark']:""); ?>' required="required" title="银行流水" placeholder="请记录银行流水" class="layui-input">
        </div>
    </div>

    <div class="layui-form-item" style="display: none">
        <label class="layui-form-label">信息记录</label>
        <div class="layui-input-block">
            <input type="text" name="infomark" value='<?php echo $recordname; ?>@<?php echo $update_time; ?>:record|' required="required" title="信息记录" placeholder="信息记录" class="layui-input">
        </div>
    </div>

    <div class="layui-form-item" style="display: none">
        <label class="layui-form-label">时间更新</label>
        <div class="layui-input-block">
            <input type="text" name="update_time" value='<?php echo $update_time; ?>' required="required" title="时间更新" placeholder="时间更新" class="layui-input">
        </div>
    </div>

    <div class="hr-line-dashed"></div>

    <div class="layui-form-item text-center">
        <?php if(isset($vo['id'])): ?><input type='hidden' value='<?php echo $vo['id']; ?>' name='id'/><?php endif; ?>
        <button class="layui-btn" type='submit'>保存数据</button>
        <button class="layui-btn layui-btn-danger" type='button' data-confirm="确定要取消编辑吗？" data-close>取消编辑</button>
    </div>


</form>
