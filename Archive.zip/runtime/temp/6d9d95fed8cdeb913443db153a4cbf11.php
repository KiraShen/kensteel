<?php if (!defined('THINK_PATH')) exit(); /*a:4:{s:41:"./template/index/default/index.index.html";i:1499824832;s:43:"./template/index/default/public.header.html";i:1499742265;s:40:"./template/index/default/public.nav.html";i:1499762868;s:43:"./template/index/default/public.footer.html";i:1499909865;}*/ ?>
<!DOCTYPE html>
<html>
<head lang="en">
  <meta charset="UTF-8">
  <title>fudazhou首页</title>
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport"
        content="width=device-width, initial-scale=1,maximum-scale=1.0, user-scalable=0,user-scalable=no">
  <meta name="format-detection" content="telephone=no">
  <meta name="renderer" content="webkit">
  <meta http-equiv="Cache-Control" content="no-siteapp"/>
  
  <link rel="alternate icon" type="img/hengwang-1.png" href="img/hengwang-1.png">
  <link rel="stylesheet" href="__CSS__/amazeui.css"/>
  <link rel="stylesheet" href="__CSS__/style.css"/>
    <!--[if lt IE 9]>
  <script src="http://libs.baidu.com/jquery/1.11.1/jquery.min.js"></script>
  <script src="http://cdn.staticfile.org/modernizr/2.8.3/modernizr.js"></script>
  <script src="__JS__/amazeui.ie8polyfill.min.js"></script>
  <![endif]-->

  <!--[if (gte IE 9)|!(IE)]><!-->
  <script src="__JS__/jquery.min.js"></script>
  <!--<![endif]-->
  <script src="__JS__/amazeui.min.js"></script>
  <script src="__JS__/scroll.js"></script>
</head>

<body>
<header class="am-topbar header">
	<div class="am-container-1">
		<div class="left hw-logo">
		  <img class=" logo" src="img/HENGWANG.png"></img>
		  <img class="word" src="img/hw-word.png"></img>
  </div>
  <button class="am-topbar-btn am-topbar-toggle am-btn am-btn-sm am-btn-success am-show-sm-only"
          data-am-collapse="{target: '#doc-topbar-collapse'}"><span class="am-sr-only">导航切换</span> <span
      class="am-icon-bars"></span>
  </button>

  <div class="am-collapse am-topbar-collapse right" id="doc-topbar-collapse">
    <div class=" am-topbar-left am-form-inline am-topbar-right" role="search">
      <ul class="am-nav am-nav-pills am-topbar-nav hw-menu">
        <?php if(is_array($nav_list) || $nav_list instanceof \think\Collection || $nav_list instanceof \think\Paginator): $i = 0; $__LIST__ = $nav_list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$nav): $mod = ($i % 2 );++$i;?>
            <li <?php if($nav['controller_name'] == $controller_name): ?>class="hw-menu-active"<?php endif; ?>><a href="<?php echo $nav['url']; ?>" title="<?php echo $nav['title']; ?>"><?php echo $nav['title']; ?></a>
            </li>
        <?php endforeach; endif; else: echo "" ;endif; ?>
    </ul>
    </div>

  </div>
  </div>
</header>

<script>
    var curr_url = window.location.href;  //获取当前URL
    $('#menu li a').each(function(i,n){  //循环导航的a标签
        var href = $(this).attr('href'); //a标签中的href链接
        if(href == curr_url){  //如果当前URL,和a标签中的href相等。
            $(this).addClass('hw-menu-active');  //那么就给这个a标签增加home_page类。
        }
    })
</script>


<div class="rollpic">
	 <div data-am-widget="slider" class="am-slider am-slider-default" data-am-slider='{}' >
	  <ul class="am-slides">
<!-- 	      <li><img src="__IMG__/hw_bg1.png"/></li>
	      <li><img src="__IMG__/hw_bg.png"/></li>  	
	      <li><img src="__IMG__/hw_bg3.png"/></li> -->
        <?php if(is_array($text_shuff_list) || $text_shuff_list instanceof \think\Collection || $text_shuff_list instanceof \think\Paginator): $k = 0; $__LIST__ = $text_shuff_list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($k % 2 );++$k;?>
          <li><img src = <?php echo $item['image']; ?> /><li>
        <?php endforeach; endif; else: echo "" ;endif; ?>

	  </ul>
    </div>
</div>		
<div class=" news-all">
	<div class="am-container-1">
<div class="news part-all">
		<div class="part-title">
			<a href="news.html">
			<i class="am-icon-newspaper-o part-title-i"></i>
			<span class="part-title-span">新闻动态</span>
			<p>Hengwang News</p>
			</a>
		</div>
		<div class="news-content ">
				<ul class="news-content-ul">
					<li class="am-u-sm-12 am-u-md-6 am-u-lg-6">
						<a href="#">
						    <div class=" am-u-sm-12 am-u-md-12 am-u-lg-5">
						    	<div class="news-img">
						    	<img src="img/news.png"></img>
						    	</div>
						    </div>
						    <div  class=" am-u-sm-12 am-u-md-12 am-u-lg-7">
										<span class="news-right-title">关于召开年会的通知</span>
										<p class="news-right-time">2015-06-11</p>
										<p class="news-right-words">互联网，又称网际网路或音译因特网、英特网，是网络与网络之间所串连成的庞大网络网络与网络之...</p>
										<a><span class="see-more2">查看更多<i class="am-icon-angle-double-right"></i></span></a>
								 </div>	
						<div class="clear"></div>
						</a>
					</li>
					<li class="am-u-sm-12 am-u-md-6 am-u-lg-6">
						<a href="#">
						    <div class=" am-u-sm-12 am-u-md-12 am-u-lg-5">
						    	<div class="news-img">
						    	<img src="img/news1.png"></img>
						    	</div>
						    </div>
						    <div  class=" am-u-sm-12 am-u-md-12 am-u-lg-7">
										<span class="news-right-title">关于召开年会的通知</span>
										<p class="news-right-time">2015-06-11</p>
										<p class="news-right-words">互联网，又称网际网路或音译因特网、英特网，是网络与网络之间所串连成的庞大网络网络与网络之...</p>
										<a><span class="see-more2">查看更多<i class="am-icon-angle-double-right"></i></span></a>
								 </div>	
						<div class="clear"></div>
						</a>
					</li>		
					<div class="clear"></div>
				</ul>
			<div class="clear"></div>
		</div>
	</div>
</div>
</div>

<div class="am-container-1">
  <div class="solutions part-all">
    <div class="part-title">
      <a href="solutions.html">
      <i class="am-icon-lightbulb-o part-title-i"></i>
      <span class="part-title-span">产品服务</span>
      <p>Solutions</p>
      </a>
    </div>
    <ul class="am-g part-content solutions-content">
      <li class="am-u-sm-6 am-u-md-3 am-u-lg-3">
        <i class="am-icon-safari solution-circle"></i>
        <span class="solutions-title">网站、移动网站</span>
        <p class="solutions-way">微信公众号开发移动网站微信公众号开发</p>
      </li>
      <li class="am-u-sm-6 am-u-md-3 am-u-lg-3">
        <i class="am-icon-magic solution-circle"></i>
        <span class="solutions-title">网站、移动网站</span>
        <p class="solutions-way">移动网站微信公众号开发移动网站微信公众号开发,解决方案</p>
      </li>
      <li class="am-u-sm-6 am-u-md-3 am-u-lg-3">
        <i class="am-icon-phone solution-circle"></i>
        <span class="solutions-title">网站、移动网站</span>
        <p class="solutions-way">移动网站微信公众号开发移动网站微信公众号开发</p>
      </li>
      <li class="am-u-sm-6 am-u-md-3 am-u-lg-3">
        <i class="am-icon-hacker-news solution-circle"></i>
        <span class="solutions-title">网站、移动网站</span>
        <p class="solutions-way">网站、移动网站微信公众号开发移动网站微信公众号开发,解决方案</p>
      </li>
      
    </ul>
    
  </div>
</div>


<script type="text/javascript">

</script>

<footer class="footer ">
	
<ul>
        
        <li class="am-u-lg-4 am-u-md-4 am-u-sm-12 part-5-li2">
            <div class="part-5-title">联系我们</div>
            <div class="part-5-words2">
                <span>地址:<?php echo sysconf('company_address'); ?></span>
                <span>电话:<?php echo sysconf('company_phone'); ?></span>
                <span>传真:<?php echo sysconf('company_fixed_line'); ?></span>
                <span>邮箱:<?php echo sysconf('company_email'); ?></span>
                <span><i class="am-icon-phone"></i><em ><?php echo sysconf('company_fixed_line'); ?></em></span>
            </div>
        </li>
        <li class="am-u-lg-4 am-u-md-4 am-u-sm-12 ">
            <div class="part-5-title">友情链接</div>
            <div class="part-5-words2">
                <ul class="part-5-words2-ul">
                    <?php if(is_array($link_list) || $link_list instanceof \think\Collection || $link_list instanceof \think\Paginator): $i = 0; $__LIST__ = $link_list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 2 );++$i;?>
                    <li class="am-u-lg-4 am-u-md-6 am-u-sm-4"><a href='<?php echo $item['url']; ?>' title='<?php echo $item['title']; ?>' target='_blank'><?php echo $item['title']; ?></a> </li>
                    <?php endforeach; endif; else: echo "" ;endif; ?>
                
                    <div class="clear"></div>
                </ul>
            </div>
        </li>
        <div class="clear"></div>
    </ul>
   <div class="copyright">
        Copyright &#169; 2017-2020 
        <a href="<?php echo sysconf('company_url'); ?>" title=" " target="_blank"><?php echo sysconf('company_url'); ?></a> 
        <a href="<?php echo sysconf('company_url'); ?>" title=" " <?php echo sysconf('company_url'); ?>" alt="" target="_blank"></a> 版权所有  
        <a href="<?php echo sysconf('company_url'); ?>" target="_blank" title="<?php echo sysconf('seo_title'); ?>"><?php echo sysconf('web_site_icp'); ?></a> 
    </div>
</footer>
</body>

</html>