<?php if (!defined('THINK_PATH')) exit(); /*a:4:{s:72:"/Users/apple/Documents/www/cms/application/index/view/article.index.html";i:1500000521;s:72:"/Users/apple/Documents/www/cms/application/index/view/public.header.html";i:1529650334;s:69:"/Users/apple/Documents/www/cms/application/index/view/public.nav.html";i:1529650174;s:72:"/Users/apple/Documents/www/cms/application/index/view/public.footer.html";i:1497930892;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Kensteel V1.0</title>

  <link rel="stylesheet" href="http://cdn.amazeui.org/amazeui/1.0.1/js/amazeui.min.js" />
  <link rel="stylesheet" href="__KUI__/css/amazeui.css" />
  <link rel="stylesheet" href="__KUI__/css/common.min.css" />
  <link rel="stylesheet" href="__KUI__/css/index.min.css" />
  <link rel="stylesheet" href="__KUI__/css/contact.min.css" />
</head>
<body>
  <div class="layout">
    <!--===========layout-header================-->
    <div class="layout-header am-hide-sm-only">
      <!--topbar start-->
<!--       <div class="topbar">
        <div class="container">
          <div class="am-g">
            <div class="am-u-md-3">
              <div class="topbar-left">
                <i class="am-icon-globe"></i>
                <div class="am-dropdown" data-am-dropdown>
                  <button class="am-btn am-btn-primary am-dropdown-toggle" data-am-dropdown-toggle>Language <span class="am-icon-caret-down"></span></button>
                  <ul class="am-dropdown-content">
                    <li><a href="#">English</a></li>
                    <li class="am-divider"></li>
                    <li><a href="#">Chinese</a></li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="am-u-md-9">
              <div class="topbar-right am-text-right am-fr">
                Follow us
                <i class="am-icon-facebook"></i>
                <i class="am-icon-twitter"></i>
                <i class="am-icon-google-plus"></i>
                <i class="am-icon-pinterest"></i>
                <i class="am-icon-instagram"></i>
                <i class="am-icon-linkedin"></i>
                <i class="am-icon-youtube-play"></i>
                <i class="am-icon-rss"></i>
                <a href="html/login.html">登录</a>
                <a href="html/register.html">注册</a>
              </div>
            </div>
          </div>
        </div>
      </div> -->
      <!--topbar end-->


      <div class="header-box" data-am-sticky>
        <!--header start-->
          <div class="container">
            <div class="header">
              <div class="am-g">
                <div class="am-u-lg-2 am-u-sm-12">
                  <div class="logo">
                    <a href=""><img src="__KUI__/images/logo.png" alt="" /></a>
                  </div>
                </div>
                <div class="am-u-md-10">
                  <div class="header-right am-fr">
                    <div class="header-contact">
                      <!-- <div class="header_contacts--item">
                                            <div class="contact_mini">
                                                <i style="color:#7c6aa6" class="contact-icon am-icon-phone"></i>
                                                <strong>0 (855) 233-5385</strong>
                                                <span>周一~周五, 8:00 - 20:00</span>
                                            </div>
                                        </div> -->
                      <div class="header_contacts--item">
                                            <div class="contact_mini">
                                                <i style="color:#7c6aa6" class="contact-icon am-icon-envelope-o"></i>
                                                <strong>kensteel@qq.com</strong>
                                                <span>随时欢迎您的来信！</span>
                                            </div>
                                        </div>
                      <div class="header_contacts--item">
                                            <div class="contact_mini">
                                                <i style="color:#7c6aa6" class="contact-icon am-icon-map-marker"></i>
                                                <strong>乌镇乐点</strong>
                                                <span>浙江乌镇镇青镇路320号</span>
                                            </div>
                                        </div>
                    </div>
                    <span style="color: black">当前登录：</span>
                      <span style="color: red"><?php echo (isset($agent_name) && ($agent_name !== '')?$agent_name:"无"); ?>&nbsp;&nbsp;</span>
                      <?php if($login_status == 1): ?>
                    <a href="http://127.0.0.1/logout.html" class="contact-btn">
                      <!-- <button type="button" class="am-btn am-btn-secondary am-radius"> -->
                      退出
                      <!-- </button> -->
                    </a>
                      <?php endif; if($login_status == 0): ?>
                    <a href="http://127.0.0.1/login.html" class="contact-btn">
                      <!-- <button type="button" class="am-btn am-btn-secondary am-radius"> -->
                      登录
                      <!-- </button> -->
                    </a>
                      <?php endif; ?>
                  </div>
                </div>
              </div>
            </div>
          </div>
        <!--header end-->
<div class="header">
    <div class="rowFluid">
        <div class="span2 col-md-12">
            <div class="logo">
                <a href="/" title="返回首页">
                    <img src="__IMG__/logo.png" alt="深圳网站建设公司_深圳网站设计_深圳网站制作_深圳免费网站制作" /></a>
            </div>
        </div>
        
        <!--nav start-->
        <div class="nav-contain">
          <div class="nav-inner">
            <!-- <ul class="am-nav am-nav-pills am-nav-justify"> -->
            <ul class="am-nav am-nav-pills">

            <?php if(is_array($nav_list) || $nav_list instanceof \think\Collection || $nav_list instanceof \think\Paginator): $i = 0; $__LIST__ = $nav_list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$nav): $mod = ($i % 2 );++$i;?>
                <li><a href="<?php echo $nav['url']; ?>" title="<?php echo $nav['title']; ?>"><?php echo $nav['title']; ?></a></li>
            <?php endforeach; endif; else: echo "" ;endif; ?>
            <!-- 
              <li "><a href="./index.html">首页</a></li>
              <li><a href="franchisee.html">沸达州加盟</a></li>  -->
              <!-- <li>
                <a href="#">产品中心</a>
                <ul class="sub-menu">
                  <li class="menu-item"><a href="html/product1.html">产品展示1</a></li>
                  <li class="menu-item"><a href="html/product2.html">产品展示2</a></li>
                  <li class="menu-item"><a href="html/product3.html">产品展示3</a></li>
                </ul>
              </li>
              <li><a href="html/example.html">客户案例</a></li>
              <li><a href="html/solution.html">解决方案</a></li>
              <li>
                <a href="html/news.html">新闻中心</a>
                <ul class="sub-menu">
                  <li class="menu-item"><a href="html/news-content.html">公司动态</a></li>
                  <li class="menu-item"><a href="html/404-dark.html">行业动态</a></li>
                  <li class="menu-item"><a href="html/404-light.html">精彩专题</a></li>
                </ul>
              </li>-->
              <!-- 
              <li><a href="html/about.html">关于我们</a></li>
              <li><a href="html/join.html">加入我们</a></li>
              <li><a href="html/contact.html">联系我们</a></li>  -->
            </ul>
          </div>
        </div>
        <!--nav end-->
      </div>
    </div>

<script>
    var curr_url = window.location.href;  //获取当前URL
    $('#menu li a').each(function(i,n){  //循环导航的a标签
        var href = $(this).attr('href'); //a标签中的href链接
        if(href == curr_url){  //如果当前URL,和a标签中的href相等。
            $(this).addClass('active');  //那么就给这个a标签增加home_page类。
        }
    })
</script>
        <div class="span2">

            <div class="login" id="_userlogin">
                <li class="toptel" style="margin-right:0px;">
                    <img src="__IMG__/dongtaitel.gif">
                    <img src="__IMG__/top-tel.png">
                </li>
            </div>
        </div>
    </div>
</div>
<div class="aside">
    <ul>

        <li><a href="#" target="_blank"><img src="__IMG__/057.png" alt="人工服务" />客服</a></li>
        <li class="consulting"><a href="#" title="建站在线客服"><span></span><span></span><span></span><img src="__IMG__/059.png" class="img1" alt="建站在线客服" /><img src="__IMG__/061.png" class="img2" alt="建站在线客服" />咨询</a></li>
        <li> <a href="help.html"><img src="__IMG__/060.png" alt="建站帮助中心" />帮助</a> </li>
    </ul>
</div>
<div class="consulting_box">
    <div class="title">
        <div class="title_t1">RELATEED CONSULTING</div>
        <div class="title_t2">相关咨询 </div>
    </div>
    <div class="consulting_type">
        <div class="consulting_type_title">QQ通讯客服</div>
        <ul>
            <li> <a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=980218641&site=qq&menu=yes" title="响应式建站咨询"> <img src="__IMG__/062.png" class="img1" alt="网站建设" /><img src="__IMG__/063.png" class="img2" alt="响应式网站咨询" />企业QQ客服 </a> </li>
            <li> <a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=980218641&site=qq&menu=yes" title="建站平台加盟咨询"> <img src="__IMG__/062.png" class="img1" alt="建站平台" /><img src="__IMG__/063.png" class="img2" alt="建站平台代理咨询" />加盟咨询 </a> </li>
            <li> <a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=980218641&site=qq&menu=yes" title="响应式网站定制"> <img src="__IMG__/062.png" class="img1" alt="响应式网站定制" /><img src="__IMG__/063.png" class="img2" alt="响应式网站定制" />定制咨询 </a> </li>
        </ul>
        <div class="consulting_type_title">电话通讯客服</div>
        <ul>
            <li> <a target="_blank" href="JavaScript:;" title="响应式建站咨询"> 服务热线：40086 15257 </a> </li>
            <li> <a target="_blank" href="JavaScript:;" title="响应式建站咨询"> 固定电话：023-81301630 </a> </li>
            <li> <a target="_blank" href="JavaScript:;" title="响应式建站咨询"> 售前咨询：189-8340-1091 </a> </li>
        </ul>

        <div class="time">服务时间：9:30-18:00</div>

    </div>
    <div class="problem">
        <div class="problem_title">你可能遇到了下面的问题</div>
        <ul>
            <li><span></span><a href="/help/seo/41.html" title="404页面该怎么做？">404页面该怎么做？</a></li>
            <li><span></span><a href="/help/seo/40.html" title="SEO菜鸟需要掌握哪些基本SEO技巧？">SEO菜鸟需要掌握哪些基本SEO技巧？</a></li>
            <li><span></span><a href="/help/seo/39.html" title="几大搜索引擎的网站登录入口">几大搜索引擎的网站登录入口</a></li>
            <li><span></span><a href="/help/seo/38.html" title="手把手教你做百度推广">手把手教你做百度推广</a></li>
            <li><span></span><a href="/help/seo/37.html" title="页面无用时间信息导致网页不被抓取">页面无用时间信息导致网页不被抓取</a></li>

        </ul>
    </div>
    <div class="close"> <img src="__IMG__/close.png" alt="关闭右侧工具栏" /> </div>
</div>

<div class="page">
    <div class="rowFluid">
        <div class="span12">
            <div class="main">
                <div class="z_banner support_z_banner">
                    <div class="rowFluid">
                        <div class="span12">
                            <div class="container">
                                <h3 class="z_banner_title">新闻中心</h3>
                                <div class="z_banner_text"> 这里有您想知道的最新资讯与动态 </div>
                            </div>
                            <ul class="platform_advantage_bg_z">
                                <li></li>
                                <li></li>
                                <li></li>
                                <li></li>
                                <li></li>
                                <li></li>
                                <li></li>
                                <li></li>
                                <li></li>
                                <li></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="support_type">
                    <div class="rowFluid">
                        <div class="span12">
                            <div class="container">
                                <div class="support_type_content">
                                    <div class="kzf-mod-center">
                                        <?php if(is_array($article_cate) || $article_cate instanceof \think\Collection || $article_cate instanceof \think\Paginator): $i = 0; $__LIST__ = $article_cate;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 2 );++$i;?>
                                        <div class="span2 col-xs-4"> <a href="<?php echo $item['url']; ?>" class="support_type_list normal <?php if($type == $item['id']): ?> active<?php endif; ?>" title="平台动态"><?php echo $item['name']; ?></a> </div>
                                        <?php endforeach; endif; else: echo "" ;endif; ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="kzf-mod-new-container">
                    <div class="rowFluid">
                        <div class="span12">
                            <div class="container" id="newslist">
                                <?php if(is_array($article_list) || $article_list instanceof \think\Collection || $article_list instanceof \think\Paginator): $i = 0; $__LIST__ = $article_list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 2 );++$i;?>
                                <div class="rowFluid">
                                    <a href="<?php echo $item['url']; ?>">
                                        <div class="kzf-mod-new-li">
                                            <div class="span2">
                                                <div class="kzf-mod-new-time-box">
                                                    <div class="kzf-mod-new-time-date"><span><?php echo date("m",$item['create_at']); ?></span>/<span><?php echo date("d",$item['create_at']); ?></span></div>
                                                    <div class="kzf-mod-new-time-year"><?php echo date("Y",$item['create_at']); ?></div>
                                                </div>
                                            </div>
                                            <div class="span10">
                                                <div class="kzf-mod-new-box">
                                                    <div class="kzf-mod-new-title"><?php echo $item['title']; ?></div>
                                                    <div class="kzf-mod-new-text"> <?php echo $item['brief']; ?></div>
                                                </div>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                                <?php endforeach; endif; else: echo "" ;endif; ?>
                               <!-- <div class="rowFluid">
                                    <a href="newsdetail.html">
                                        <div class="kzf-mod-new-li">
                                            <div class="span2">
                                                <div class="kzf-mod-new-time-box">
                                                    <div class="kzf-mod-new-time-date"><span>03</span>/<span>24</span></div>
                                                    <div class="kzf-mod-new-time-year">2017</div>
                                                </div>
                                            </div>
                                            <div class="span10">
                                                <div class="kzf-mod-new-box">
                                                    <div class="kzf-mod-new-title">设计一个好的新闻类内容详情页，不得不注意的三大方面</div>
                                                    <div class="kzf-mod-new-text"> 只有站在受众角度，将个性化、精选的内容送达用户，精准匹配、促进互动，进而形成自有势能。</div>
                                                </div>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                                <div class="rowFluid"> <a href="newsdetail.html">
                                <div class="kzf-mod-new-li">
                                    <div class="span2">
                                        <div class="kzf-mod-new-time-box">
                                            <div class="kzf-mod-new-time-date"><span>03</span>/<span>24</span></div>
                                            <div class="kzf-mod-new-time-year">2017</div>
                                        </div>
                                    </div>
                                    <div class="span10">
                                        <div class="kzf-mod-new-box">
                                            <div class="kzf-mod-new-title">Struts 2 再曝高危漏洞，请立即升级，这不是演习！</div>
                                            <div class="kzf-mod-new-text"> 此时此刻，很多网络安全人员、IT 运维人员的内心是崩溃的。</div>
                                        </div>
                                    </div>
                                </div>
                            </a> </div><div class="rowFluid"> <a href="newsdetail.html">
                                <div class="kzf-mod-new-li">
                                    <div class="span2">
                                        <div class="kzf-mod-new-time-box">
                                            <div class="kzf-mod-new-time-date"><span>03</span>/<span>24</span></div>
                                            <div class="kzf-mod-new-time-year">2017</div>
                                        </div>
                                    </div>
                                    <div class="span10">
                                        <div class="kzf-mod-new-box">
                                            <div class="kzf-mod-new-title">妻子遭黑客勒索却安然无恙，当事人亲述如何防止勒索软件</div>
                                            <div class="kzf-mod-new-text"> CryptoLocker勒索软件可以劫持用户的网络摄像头，并录下一些不可描述的画面。</div>
                                        </div>
                                    </div>
                                </div>
                            </a> </div><div class="rowFluid"> <a href="newsdetail.html">
                                <div class="kzf-mod-new-li">
                                    <div class="span2">
                                        <div class="kzf-mod-new-time-box">
                                            <div class="kzf-mod-new-time-date"><span>03</span>/<span>24</span></div>
                                            <div class="kzf-mod-new-time-year">2017</div>
                                        </div>
                                    </div>
                                    <div class="span10">
                                        <div class="kzf-mod-new-box">
                                            <div class="kzf-mod-new-title">碎片化学习VS系统化学习：如何系统地学习新媒体知识？</div>
                                            <div class="kzf-mod-new-text"> 最全的新媒体知识大纲。 ,鸟哥笔记</div>
                                        </div>
                                    </div>
                                </div>
                            </a> </div><div class="rowFluid"> <a href="newsdetail.html">
                                <div class="kzf-mod-new-li">
                                    <div class="span2">
                                        <div class="kzf-mod-new-time-box">
                                            <div class="kzf-mod-new-time-date"><span>03</span>/<span>24</span></div>
                                            <div class="kzf-mod-new-time-year">2017</div>
                                        </div>
                                    </div>
                                    <div class="span10">
                                        <div class="kzf-mod-new-box">
                                            <div class="kzf-mod-new-title">百度取消了新闻源？！VIP俱乐部申请升级</div>
                                            <div class="kzf-mod-new-text"> 近日，百度发布公告称，原独立新闻源数据库的形式已经不再适用，因而取消了新闻源数据库……</div>
                                        </div>
                                    </div>
                                </div>
                            </a> </div><div class="rowFluid"> <a href="newsdetail.html">
                                <div class="kzf-mod-new-li">
                                    <div class="span2">
                                        <div class="kzf-mod-new-time-box">
                                            <div class="kzf-mod-new-time-date"><span>03</span>/<span>24</span></div>
                                            <div class="kzf-mod-new-time-year">2017</div>
                                        </div>
                                    </div>
                                    <div class="span10">
                                        <div class="kzf-mod-new-box">
                                            <div class="kzf-mod-new-title">黑产马仔躲山里柴油机发电搞攻击，幕后老大闹市喝茶——老司机独</div>
                                            <div class="kzf-mod-new-text"> 时刻警惕与抵抗赛博世界的攻方来袭，揪出背后的始作俑者，这是绿盟科技的高级副总裁叶晓虎置身攻防战斗 15 年来最重要的工作。</div>
                                        </div>
                                    </div>
                                </div>
                            </a> </div><div class="rowFluid"> <a href="newsdetail.html">
                                <div class="kzf-mod-new-li">
                                    <div class="span2">
                                        <div class="kzf-mod-new-time-box">
                                            <div class="kzf-mod-new-time-date"><span>03</span>/<span>24</span></div>
                                            <div class="kzf-mod-new-time-year">2017</div>
                                        </div>
                                    </div>
                                    <div class="span10">
                                        <div class="kzf-mod-new-box">
                                            <div class="kzf-mod-new-title">离奇电信诈骗：一夜损失 52000元，毒品、情妇、黑客交织的犯罪网</div>
                                            <div class="kzf-mod-new-text"> 手机、银行卡都在身边，他却一夜之间被盗 52000元！这不是故事，这是真实发生的事情……</div>
                                        </div>
                                    </div>
                                </div>
                            </a> </div><div class="rowFluid"> <a href="newsdetail.html">
                                <div class="kzf-mod-new-li">
                                    <div class="span2">
                                        <div class="kzf-mod-new-time-box">
                                            <div class="kzf-mod-new-time-date"><span>03</span>/<span>24</span></div>
                                            <div class="kzf-mod-new-time-year">2017</div>
                                        </div>
                                    </div>
                                    <div class="span10">
                                        <div class="kzf-mod-new-box">
                                            <div class="kzf-mod-new-title">新媒体编辑一定要知道的55个常用术语</div>
                                            <div class="kzf-mod-new-text"> 55个有关新媒体编辑的高级机密送给你们 ,鸟哥笔记</div>
                                        </div>
                                    </div>
                                </div>
                            </a> </div> </div>-->
                            <div style="text-align: center;" id="pages">

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<link rel="stylesheet" href="__PUBLIC__/static/plugs/layui/css/layui.css?ver=<?php echo date('ymd'); ?>"/>
<script src="__PUBLIC__/static/plugs/layui/layui.js?ver=<?php echo date('ymd'); ?>"></script>
<script>
    layui.use(['laypage', 'layer'], function(){
        var laypage = layui.laypage,layer = layui.layer;
        laypage({
            cont: 'pages',
            skin: '#AF0000',
            skip: true, //是否开启跳页
            pages: <?php echo $allpage; ?>, //可以叫服务端把总页数放在某一个隐藏域，再获取。假设我们获取到的是18
            curr: function(){ //通过url获取当前页，也可以同上（pages）方式获取
                var page = location.search.match(/page=(\d+)/);
                return page ? page[1] : 1;
            }(),
            jump: function(e, first){ //触发分页后的回调
                if(!first){ //一定要加此判断，否则初始时会无限刷新
                    location.href = '?page='+e.curr;
                }
            }
        });
    });
</script>
    <div class="footer wow fadeInUp">
    <div class="rowFluid">
        <div class="span12">
            <div class="container">
                <div class="footer_content">
                    <div class="span4 col-xm-12">
                        <div class="footer_list">
                            <div class="span6">
                                <div class="bottom_logo"><p style="color: #D9D9DA;font-size: 16px;">关注我们</p>这是二维码</div>
                            </div>
                            <div class="span6 col-xm-12">
                                <div class="quick_navigation">
                                    <div class="quick_navigation_title">快速导航</div>
                                    <ul>
                                        <?php if(is_array($nav_list) || $nav_list instanceof \think\Collection || $nav_list instanceof \think\Paginator): $i = 0; $__LIST__ = $nav_list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$nav): $mod = ($i % 2 );++$i;?>
                                        <li><a href="<?php echo $nav['url']; ?>" title="<?php echo $nav['title']; ?>"><?php echo $nav['title']; ?></a></li>
                                        <?php endforeach; endif; else: echo "" ;endif; ?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="span4 col-xm-6 col-xs-12">
                        <div class="footer_list">
                            <div class="footer_link">
                                <div class="footer_link_title">友情链接</div>
                                <ul id="frientLinks">
                                    <?php if(is_array($link_list) || $link_list instanceof \think\Collection || $link_list instanceof \think\Paginator): $i = 0; $__LIST__ = $link_list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 2 );++$i;?>
                                    <li><a href='<?php echo $item['url']; ?>' title='<?php echo $item['title']; ?>' target='_blank'><?php echo $item['title']; ?></a> </li>
                                    <?php endforeach; endif; else: echo "" ;endif; ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="span4 col-xm-6 col-xs-12">
                        <div class="footer_list">
                            <div class="footer_cotact">
                                <div class="footer_cotact_title">联系方式</div>
                                <ul>
                                    <li><span class="footer_cotact_type">地址：</span><span class="footer_cotact_content"><a href="http://j.map.baidu.com/dZ3N3" target="_blank"><?php echo sysconf('company_address'); ?></a></span></li>
                                    <li><span class="footer_cotact_type">电话：</span><span class="footer_cotact_content"><a href="tel:<?php echo sysconf('company_phone'); ?>" class="call"><?php echo sysconf('company_phone'); ?></a></span></li>
                                    <li><span class="footer_cotact_type">固话：</span><span class="footer_cotact_content"><a href="tel:<?php echo sysconf('company_fixed_line'); ?>" class="call"><?php echo sysconf('company_fixed_line'); ?></a></span></li>
                                    <li><span class="footer_cotact_type">ＱＱ：</span><span class="footer_cotact_content"><a href="#" class="call"><?php echo sysconf('company_qq'); ?></a></span></li>
                                    <li><span class="footer_cotact_type">网址：</span><span class="footer_cotact_content"><a href="<?php echo sysconf('company_url'); ?>" title="官网"><?php echo sysconf('company_url'); ?></a></span></li>
                                    <li><span class="footer_cotact_type">邮箱：</span><span class="footer_cotact_content"><?php echo sysconf('company_email'); ?></span></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="copyright">Copyright &#169; 2017-2020 <a href="<?php echo sysconf('company_url'); ?>" title="深圳网站建设,深圳网站定制,深圳商城开发,深圳电商网站,深圳响应式网站建设,深圳HTML5网站建设,深圳营销型网站建设" target="_blank"><?php echo sysconf('company_url'); ?></a> <a href="<?php echo sysconf('company_url'); ?>" title="<?php echo sysconf('company_url'); ?>" alt="深圳网站建设,深圳网站定制,深圳商城开发,深圳电商网站,深圳响应式网站建设,深圳HTML5网站建设,深圳营销型网站建设" target="_blank">93网</a> 版权所有  <a href="<?php echo sysconf('company_url'); ?>" target="_blank" title="<?php echo sysconf('seo_title'); ?>"><?php echo sysconf('web_site_icp'); ?></a> </div>
        </div>
    </div>
</div>
    </div>
    </div>
    </div>
    </div>
</body>
</html>

