<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:75:"/Users/apple/Documents/www/cms/application/shares/view/agent.user_form.html";i:1529372466;}*/ ?>
<form class="layui-form layui-box" style='padding:25px 30px 20px 0' action="__SELF__" data-auto="true" method="post">


    <div class="layui-form-item">
        <label class="layui-form-label">姓</label>
        <div class="layui-input-block">
            <input type="text" name="last_name" value='<?php echo (isset($vo['last_name']) && ($vo['last_name'] !== '')?$vo['last_name']:""); ?>' required="required" title="姓" placeholder="姓" class="layui-input">
        </div>
    </div>
    
    <div class="layui-form-item">
     <label class="layui-form-label">名</label>
        <div class="layui-input-block">
            <input type="text" name="first_name" value='<?php echo (isset($vo['first_name']) && ($vo['first_name'] !== '')?$vo['first_name']:""); ?>' required="required" title="名" placeholder="名" class="layui-input">
        </div>
    </div>

    <div class="layui-form-item">
     <label class="layui-form-label">手机号</label>
        <div class="layui-input-block">
            <input type="text" name="phone" value='<?php echo (isset($vo['phone']) && ($vo['phone'] !== '')?$vo['phone']:""); ?>' required="required" title="手机号" placeholder="手机号" class="layui-input">
        </div>
    </div>
    
    <div class="layui-form-item">
        <label class="layui-form-label">身份证号</label>
        <div class="layui-input-block">
            <input type="text" name="code" value='<?php echo (isset($vo['code']) && ($vo['code'] !== '')?$vo['code']:""); ?>' required="identity" title="身份证号" placeholder="身份证号" class="layui-input">
        </div>
    </div>

    <div class="layui-form-item">
     <label class="layui-form-label">身份证地址</label>
        <div class="layui-input-block">
            <input type="text" name="address" value='<?php echo (isset($vo['address']) && ($vo['address'] !== '')?$vo['address']:""); ?>' required="required" title="身份证地址" placeholder="身份证地址" class="layui-input">
        </div>
    </div>

    <div class="hr-line-dashed"></div>

    <div class="layui-form-item text-center">
        <?php if(isset($vo['id'])): ?><input type='hidden' value='<?php echo $vo['id']; ?>' name='id'/><?php endif; ?>
        <button class="layui-btn" type='submit'>保存数据</button>
        <button class="layui-btn layui-btn-danger" type='button' data-confirm="确定要取消编辑吗？" data-close>取消编辑</button>
    </div>


</form>
