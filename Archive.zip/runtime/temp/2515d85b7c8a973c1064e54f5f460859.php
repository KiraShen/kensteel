<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:74:"/Users/apple/Documents/www/cms/application/shares/view/info.info_form.html";i:1529822945;}*/ ?>
<form class="layui-form layui-box" style='padding:25px 40px 20px 0' action="__SELF__" data-auto="true" method="">


    <div class="layui-form-item">
        <label class="layui-form-label">代理名称</label>
        <div class="layui-input-block">
            <input type="text" name="agent_name" value='<?php echo (isset($vo['agent_name']) && ($vo['agent_name'] !== '')?$vo['agent_name']:""); ?>' readonly="true" class="layui-input">
        </div>
    </div>
    <div class="layui-form-item">
        <label class="layui-form-label">分类</label>
        <div class="layui-input-block">
            <input type="text" name="type_name" value='<?php echo (isset($vo['type_name']) && ($vo['type_name'] !== '')?$vo['type_name']:""); ?>' readonly="true" class="layui-input">
        </div>
    </div>
    <div class="layui-form-item">
        <label class="layui-form-label">姓名</label>
        <div class="layui-input-block">
            <input type="text" name="first_name" value='<?php echo (isset($vo['last_name']) && ($vo['last_name'] !== '')?$vo['last_name']:""); ?><?php echo (isset($vo['first_name']) && ($vo['first_name'] !== '')?$vo['first_name']:""); ?>' readonly="true" class="layui-input">
        </div>
    </div>
        <div class="layui-form-item">
     <label class="layui-form-label">套餐金额</label>
        <div class="layui-input-block">
            <input type="text" name="money" value='<?php echo (isset($vo['money']) && ($vo['money'] !== '')?$vo['money']:""); ?>' readonly="true" class="layui-input">
        </div>
    </div>

    <div class="layui-form-item">
        <label class="layui-form-label">股票数量</label>
        <div class="layui-input-block">
            <input type="text" name="shares" value='<?php echo (isset($vo['shares']) && ($vo['shares'] !== '')?$vo['shares']:""); ?>' readonly="true" class="layui-input">
        </div>
    </div>

    <div class="layui-form-item">
        <label class="layui-form-label">身份证</label>
        <div class="layui-input-block">
            <input type="text" name="code" value='<?php echo (isset($vo['code']) && ($vo['code'] !== '')?$vo['code']:""); ?>' readonly="true" class="layui-input">
        </div>
    </div>

    <div class="layui-form-item">
        <label class="layui-form-label">地址</label>
        <div class="layui-input-block">
            <input type="text" name="address" value='<?php echo (isset($vo['address']) && ($vo['address'] !== '')?$vo['address']:""); ?>' readonly="true" class="layui-input">
        </div>
    </div>

    <div class="layui-form-item">
        <label class="layui-form-label">银行信息</label>
        <div class="layui-input-block">
            <input type="text" name="bankinfo" value='<?php echo (isset($vo['bankinfo']) && ($vo['bankinfo'] !== '')?$vo['bankinfo']:""); ?>' readonly="true" class="layui-input">
        </div>
    </div>
    
    <div class="layui-form-item">
        <label class="layui-form-label">银行号码</label>
        <div class="layui-input-block">
            <input type="text" name="banknum" value='<?php echo (isset($vo['banknum']) && ($vo['banknum'] !== '')?$vo['banknum']:""); ?>' readonly="true" class="layui-input">
        </div>
    </div>
    
    <div class="layui-form-item">
        <label class="layui-form-label">汇款流水</label>
        <div class="layui-input-block">
            <input type="text" name="remark" value='<?php echo (isset($vo['remark']) && ($vo['remark'] !== '')?$vo['remark']:""); ?>' required="required" class="layui-input">
        </div>
    </div>
    <div class="layui-form-item" style="display: none;">
        <label class="layui-form-label">状态</label>
        <div class="layui-input-block">  
            <input type="text" name="status" value='<?php echo (isset($vo['status']) && ($vo['status'] !== '')?$vo['status']:""); ?>' readonly="true" class="layui-input">
        </div>
    </div>
    <div class="layui-form-item" style="display: none;">
        <label class="layui-form-label">信息记录</label>
        <div class="layui-input-block">  
            <input type="text" name="infomark" value='<?php echo (isset($vo['infomark']) && ($vo['infomark'] !== '')?$vo['infomark']:""); ?>' readonly="true" class="layui-input">
        </div>
    </div>

    <div class="hr-line-dashed"></div>

    <div class="layui-form-item text-center">
        <?php if(isset($vo['id'])): ?><input type='hidden' value='<?php echo $vo['id']; ?>' name='id'/><?php endif; ?>
        <button class="layui-btn" type='submit'>确认信息验证</button>
        <button class="layui-btn layui-btn-danger" type='button' data-confirm="确定要取消吗？" data-close>取消</button>
    </div>


</form>
