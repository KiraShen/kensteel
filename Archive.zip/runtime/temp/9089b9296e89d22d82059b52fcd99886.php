<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:71:"/Users/apple/Documents/www/cms/application/admin/view/config.index.html";i:1497930892;s:72:"/Users/apple/Documents/www/cms/application/extra/view/admin.content.html";i:1497930894;}*/ ?>
<div class="ibox">
    
    <?php if(isset($title)): ?>
    <div class="ibox-title">
        <h5><?php echo $title; ?></h5>
        
    </div>
    <?php endif; ?>
    <div class="ibox-content fadeInUp animated">
        <?php if(isset($alert)): ?>
        <div class="alert alert-<?php echo $alert['type']; ?> alert-dismissible" role="alert" style="border-radius:0">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            <?php if(isset($alert['title'])): ?><p style="font-size:18px;padding-bottom:10px"><?php echo $alert['title']; ?></p><?php endif; if(isset($alert['content'])): ?><p style="font-size:14px"><?php echo $alert['content']; ?></p><?php endif; ?>
        </div>
        <?php endif; ?>
        
<form onsubmit="return false;" action="__SELF__" data-auto="true" method="post" class='form-horizontal'>
    <div class="layui-tab layui-tab-card">
        <ul class="layui-tab-title">
            <li class="layui-this">后台设置</li>
            <li>前台设置</li>
            <li>文件设置</li>

            <li>其他设置</li>
        </ul>
    <div class="layui-tab-content">
        <div class="layui-tab-item layui-show">
            <div class="form-group">
                <label class="col-sm-2 control-label">SiteName <span class="nowrap">(网站名称)</span></label>
                <div class='col-sm-8'>
                    <input type="text" name="site_name" required="required" title="请输入网站名称" placeholder="请输入网站名称" value="<?php echo sysconf('site_name'); ?>" class="layui-input">
                    <p class="help-block">网站名称，显示在浏览器标签上</p>
                </div>
            </div>

            <div class="form-group">
                <label class="col-sm-2 control-label">Copyright <span class="nowrap">(版权信息)</span></label>
                <div class='col-sm-8'>
                    <input type="text" name="site_copy" required="required" title="请输入版权信息" placeholder="请输入版权信息" value="<?php echo sysconf('site_copy'); ?>" class="layui-input">
                    <p class="help-block">程序的版权信息设置，在后台登录页面显示</p>
                </div>
            </div>

            <div class="form-group">
                <label class="col-sm-2 control-label">AppName <span class="nowrap">(程序名称)</span></label>
                <div class='col-sm-8'>
                    <input type="text" name="app_name" required="required" title="请输入程序名称" placeholder="请输入程序名称" value="<?php echo sysconf('app_name'); ?>" class="layui-input">
                    <p class="help-block">当前程序名称，在后台主标题上显示</p>
                </div>
            </div>


            <div class="form-group">
                <label class="col-sm-2 control-label">AppVersion <span class="nowrap">(程序版本)</span></label>
                <div class='col-sm-8'>
                    <input type="text" name="app_version" required="required" title="请输入程序版本" placeholder="请输入程序版本" value="<?php echo sysconf('app_version'); ?>" class="layui-input">
                    <p class="help-block">当前程序版本号，在后台主标题上标显示</p>
                </div>
            </div>

            <div class="form-group">
                <label class="col-sm-2 control-label">Baidu <span class="nowrap">(百度统计)</span></label>
                <div class='col-sm-8'>
                    <input type="text" name="tongji_baidu_key" maxlength="32" pattern="^[0-9a-z]{32}$" title="请输入32位百度统计应用ID" placeholder="请输入32位百度统计应用ID" value="<?php echo sysconf('tongji_baidu_key'); ?>" class="layui-input">
                    <p class="help-block">百度统计应用ID，可以在<a target="_blank" href="https://tongji.baidu.com">百度网站统计</a>申请并获取</p>
                </div>
            </div>

            <div class="form-group">
                <label class="col-sm-2 control-label">CNZZ <span class="nowrap">(友盟统计)</span></label>
                <div class='col-sm-8'>
                    <input type="text" name="tongji_cnzz_key" maxlength="32" pattern="^[0-9]{10}$" title="请输入10位CNZZ统计应用ID" placeholder="请输入10位CNZZ统计应用ID" value="<?php echo sysconf('tongji_cnzz_key'); ?>" class="layui-input">
                    <p class="help-block">友盟统计应用ID，可以在<a target="_blank" href="https://web.umeng.com">友盟网站统计</a>申请并获取</p>
                </div>
            </div>

            <div class="form-group">
                <label class="col-sm-2 control-label">BrowserIcon <span class="nowrap">(浏览器图标)</span></label>
                <div class='col-sm-8'>
                    <img data-tips-image style="height:auto;max-height:32px;min-width:32px" src="<?php echo sysconf('browser_icon'); ?>"/>
                    <input type="hidden" name="browser_icon" onchange="$(this).prev('img').attr('src', this.value)"
                           value="<?php echo sysconf('browser_icon'); ?>" class="layui-input">
                    <a class="btn btn-link" data-file="one" data-type="ico,png" data-field="browser_icon">上传图片</a>
                    <p>建议上传ICO图标的尺寸为128x128px，此图标用于网站标题前，ICON在线制作。</p>
                </div>
            </div>
          </div>
        <div class="layui-tab-item">
            <div class="form-group">
                <label class="col-sm-2 control-label">网站标题</label>
                <div class='col-sm-8'>
                    <input type="text" name="seo_title" required="required" title="请输入网站标题" placeholder="请输入网站标题" value="<?php echo sysconf('seo_title'); ?>" class="layui-input">
                    <p class="help-block">网站标题，seo标题</p>
                </div>
            </div>
            <div class="form-group">
                <label class="col-sm-2 control-label">站点状态</label>
                <div class='col-sm-8'>
                    <select class="layui-input" name="web_site_close" required="required">
                        <option value='1'>是</option>
                        <option value='0'>否</option>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label class="col-sm-2 control-label">网站备案号</label>
                <div class='col-sm-8'>
                    <input type="text" name="web_site_icp" required="required" title="请输入网站备案号" placeholder="请输入网站备案号" value="<?php echo sysconf('web_site_icp'); ?>" class="layui-input">
                </div>
            </div>

            <div class="form-group">
                <label class="col-sm-2 control-label">seo关键词</label>
                <div class='col-sm-8'>
                     <textarea name="seo_keywords" maxlength="10000" title="seo关键词为空哦" placeholder="seo关键词"  class="form-control" style="height:100px"><?php echo sysconf('seo_keywords'); ?></textarea>

                </div>
            </div>
            <div class="form-group">
                <label class="col-sm-2 control-label">seo描述</label>
                <div class='col-sm-8'>
                    <textarea name="seo_description" maxlength="10000" title="seo描述为空哦" placeholder="seo描述"  class="form-control" style="height:100px"><?php echo sysconf('seo_description'); ?></textarea>

                </div>
            </div>
         </div>
        <div class="layui-tab-item">
            <div class="form-group">
                <label class="col-sm-2 control-label">Storage <span class="nowrap">(存储引擎)</span></label>
                <div class='col-sm-8'>
                    <select class="layui-input" name="storage_type" required="required">
                        <!--<?php if(sysconf('storage_type') == 'qiniu'): ?>-->
                        <option value='local'>本地服务器</option>
                        <option selected="selected" value='qiniu'>七牛云存储</option>
                        <option value='oss'>AliOSS存储</option>
                        <!--<?php elseif(sysconf('storage_type') == 'oss'): ?>-->
                        <option value='local'>本地服务器</option>
                        <option value='qiniu'>七牛云存储</option>
                        <option selected="selected" value='oss'>AliOSS存储</option>
                        <!--<?php else: ?>-->
                        <option selected="selected" value='local'>本地服务器</option>
                        <option value='qiniu'>七牛云存储</option>
                        <option value='oss'>AliOSS存储</option>
                        <!--<?php endif; ?>-->
                    </select>
                    <div class="help-block" data-storage-type="qiniu">
                        若还没有七牛云帐号，请点击
                        <a target="_blank" href="https://portal.qiniu.com/signup?code=3lhz6nmnwbple">免费申请10G存储空间</a>,
                        申请成功后添加公开bucket空间
                    </div>
                    <div class="help-block" data-storage-type="oss">
                        若还没有AliOSS存储账号, 请点击 <a target="_blank" href="https://oss.console.aliyun.com">创建AliOSS存储空间</a>,
                        目前仅支持公开空间URL访问, 另外还需要配置AliOSS跨域策略
                    </div>
                </div>
            </div>

            <div class="hr-line-dashed" data-storage-type="qiniu"></div>

            <div class="form-group" data-storage-type="qiniu">
                <label class="col-sm-2 control-label">Region <span class="nowrap">(存储区域)</span></label>
                <div class='col-sm-8'>
                    <select class="layui-input" name="storage_qiniu_region" required="required">

                        <!--<?php if(sysconf('storage_qiniu_region') == '华东'): ?>-->
                        <option selected value='华东'>华东</option>
                        <!--<?php else: ?>-->
                        <option value='华东'>华东</option>
                        <!--<?php endif; ?>-->

                        <!--<?php if(sysconf('storage_qiniu_region') == '华北'): ?>-->
                        <option selected value='华北'>华北</option>
                        <!--<?php else: ?>-->
                        <option value='华北'>华北</option>
                        <!--<?php endif; ?>-->

                        <!--<?php if(sysconf('storage_qiniu_region') == '华南'): ?>-->
                        <option selected value='华南'>华南</option>
                        <!--<?php else: ?>-->
                        <option value='华南'>华南</option>
                        <!--<?php endif; ?>-->

                        <!--<?php if(sysconf('storage_qiniu_region') == '北美'): ?>-->
                        <option selected value='北美'>北美</option>
                        <!--<?php else: ?>-->
                        <option value='北美'>北美</option>
                        <!--<?php endif; ?>-->

                    </select>
                    <p class="help-block">七牛云存储空间所在区域，需要严格对应储存所在区域才能上传文件</p>
                </div>
            </div>

            <div class="form-group" data-storage-type="qiniu">
                <label class="col-sm-2 control-label">Protocol <span class="nowrap">(访问协议)</span></label>
                <div class='col-sm-8'>
                    <select class="layui-input" name="storage_qiniu_is_https" required="required">
                        <!--<?php if(sysconf('storage_qiniu_is_https')!=='1'): ?>-->
                        <option selected value='0'>HTTP</option>
                        <option value='1'>HTTPS</option>
                        <!--<?php else: ?>-->
                        <option value='0'>HTTP</option>
                        <option selected value='1'>HTTPS</option>
                        <!--<?php endif; ?>-->
                    </select>
                    <p class="help-block">七牛云资源访问协议（HTTP 或 HTTPS），HTTPS 需要配置证书才能使用</p>
                </div>
            </div>


            <div class="form-group" data-storage-type="qiniu">
                <label class="col-sm-2 control-label">Bucket <span class="nowrap">(空间名称)</span></label>
                <div class='col-sm-8'>
                    <input type="text" name="storage_qiniu_bucket" required="required" title="请输入七牛云存储 Bucket (空间名称)"
                           placeholder="请输入七牛云存储 Bucket (空间名称)" value="<?php echo sysconf('storage_qiniu_bucket'); ?>"
                           class="layui-input">
                    <p class="help-block">填写七牛云存储空间名称，如：static</p>
                </div>
            </div>

            <div class="form-group" data-storage-type="qiniu">
                <label class="col-sm-2 control-label">Domain <span class="nowrap">(访问域名)</span></label>
                <div class='col-sm-8'>
                    <input type="text" name="storage_qiniu_domain" required="required" title="请输入七牛云存储 Domain (访问域名)"
                           placeholder="请输入七牛云存储 Domain (访问域名)" value="<?php echo sysconf('storage_qiniu_domain'); ?>" class="layui-input">
                    <p class="help-block">填写七牛云存储访问域名，如：static.ctolog.cc</p>
                </div>
            </div>

            <div class="form-group" data-storage-type="qiniu">
                <label class="col-sm-2 control-label">AccessKey <span class="nowrap">(访问密钥)</span></label>
                <div class='col-sm-8'>
                    <input type="text" name="storage_qiniu_access_key" required="required" title="请输入七牛云 AccessKey (访问密钥)"
                           placeholder="请输入七牛云 AccessKey (访问密钥)" value="<?php echo sysconf('storage_qiniu_access_key'); ?>" class="layui-input">
                    <p class="help-block">可以在 [ 七牛云 > 个人中心 ] 设置并获取到访问密钥</p>
                </div>
            </div>


            <div class="form-group" data-storage-type="qiniu">
                <label class="col-sm-2 control-label">SecretKey <span class="nowrap">(安全密钥)</span></label>
                <div class='col-sm-8'>
                    <input type="password" name="storage_qiniu_secret_key" required="required" title="请输入七牛云 SecretKey (安全密钥)"
                           placeholder="请输入七牛云 SecretKey (安全密钥)" value="<?php echo sysconf('storage_qiniu_secret_key'); ?>"
                           maxlength="43" class="layui-input">
                    <p class="help-block">可以在 [ 七牛云 > 个人中心 ] 设置并获取到安全密钥</p>
                </div>
            </div>

            <div class="form-group" data-storage-type="oss">
                <label class="col-sm-2 control-label">Protocol <span class="nowrap">(访问协议)</span></label>
                <div class='col-sm-8'>
                    <select class="layui-input" name="storage_oss_is_https" required="required">
                        <!--<?php if(sysconf('storage_oss_is_https')!=='1'): ?>-->
                        <option selected value='0'>HTTP</option>
                        <option value='1'>HTTPS</option>
                        <!--<?php else: ?>-->
                        <option value='0'>HTTP</option>
                        <option selected value='1'>HTTPS</option>
                        <!--<?php endif; ?>-->
                    </select>
                    <p class="help-block">AliOSS资源访问协议（HTTP 或 HTTPS），HTTPS 需要配置证书才能使用</p>
                </div>
            </div>

            <div class="form-group" data-storage-type="oss">
                <label class="col-sm-2 control-label">Bucket <span class="nowrap">(空间名称)</span></label>
                <div class='col-sm-8'>
                    <input type="text" name="storage_oss_bucket" required="required" title="请输入AliOSS Bucket (空间名称)"
                           placeholder="请输入AliOSS Bucket (空间名称)" value="<?php echo sysconf('storage_oss_bucket'); ?>" class="layui-input">
                    <p class="help-block">填写OSS存储空间名称，如：static</p>
                </div>
            </div>

            <div class="form-group" data-storage-type="oss">
                <label class="col-sm-2 control-label">Domain <span class="nowrap">(访问域名)</span></label>
                <div class='col-sm-8'>
                    <input type="text" name="storage_oss_domain" required="required" title="请输入AliOSS存储 Domain (访问域名)"
                           placeholder="请输入AliOSS存储 Domain (访问域名)" value="<?php echo sysconf('storage_oss_domain'); ?>" class="layui-input">
                    <p class="help-block">填写OSS存储外部访问域名，如：static.ctolog.cc</p>
                </div>
            </div>

            <div class="form-group" data-storage-type="oss">
                <label class="col-sm-2 control-label">AccessKey <span class="nowrap">(访问密钥)</span></label>
                <div class='col-sm-8'>
                    <input type="text" name="storage_oss_keyid" required="required" title="请输入16位AliOSS AccessKey (访问密钥)"
                           placeholder="请输入AliOSS AccessKey (访问密钥)" value="<?php echo sysconf('storage_oss_keyid'); ?>" maxlength="16" class="layui-input">
                    <p class="help-block">可以在 [ 阿里云 > 个人中心 ] 设置并获取到访问密钥</p>
                </div>
            </div>


            <div class="form-group" data-storage-type="oss">
                <label class="col-sm-2 control-label">SecretKey <span class="nowrap">(安全密钥)</span></label>
                <div class='col-sm-8'>
                    <input type="password" name="storage_oss_secret" required="required" title="请输入30位AliOSS SecretKey (安全密钥)"
                           placeholder="请输入AliOSS SecretKey (安全密钥)" value="<?php echo sysconf('storage_oss_secret'); ?>" maxlength="30" class="layui-input">
                    <p class="help-block">可以在 [ 阿里云 > 个人中心 ] 设置并获取到安全密钥</p>
                </div>
            </div>
        </div>
        <div class="layui-tab-item">
            <div class="form-group">
                <label class="col-sm-2 control-label">总部</label>
                <div class='col-sm-8'>
                    <input type="text" name="company_headquarters"  placeholder="总部" value="<?php echo sysconf('company_headquarters'); ?>" class="layui-input">
                </div>
            </div>
            <div class="form-group">
                <label class="col-sm-2 control-label">公司地址</label>
                <div class='col-sm-8'>
                    <input type="text" name="company_address"  placeholder="公司地址" value="<?php echo sysconf('company_address'); ?>" class="layui-input">
                </div>
            </div>
            <div class="form-group">
                <label class="col-sm-2 control-label">电话</label>
                <div class='col-sm-8'>
                    <input type="text" name="company_phone"  placeholder="电话" value="<?php echo sysconf('company_phone'); ?>" class="layui-input">
                </div>
            </div>
            <div class="form-group">
                <label class="col-sm-2 control-label">固话</label>
                <div class='col-sm-8'>
                    <input type="text" name="company_fixed_line"  placeholder="固话" value="<?php echo sysconf('company_fixed_line'); ?>" class="layui-input">
                </div>
            </div>
            <div class="form-group">
                <label class="col-sm-2 control-label">QQ</label>
                <div class='col-sm-8'>
                    <input type="text" name="company_qq"  placeholder="QQ" value="<?php echo sysconf('company_qq'); ?>" class="layui-input">
                </div>
            </div>
            <div class="form-group">
                <label class="col-sm-2 control-label">网址</label>
                <div class='col-sm-8'>
                    <input type="text" name="company_url"  placeholder="网址" value="<?php echo sysconf('company_url'); ?>" class="layui-input">
                </div>
            </div>
            <div class="form-group">
                <label class="col-sm-2 control-label">邮箱</label>
                <div class='col-sm-8'>
                    <input type="text" name="company_email"  placeholder="邮箱" value="<?php echo sysconf('company_email'); ?>" class="layui-input">
                </div>
            </div>
            <div class="form-group">
                <label class="col-sm-2 control-label">负责人</label>
                <div class='col-sm-8'>
                    <input type="text" name="company_head"  placeholder="负责人" value="<?php echo sysconf('company_head'); ?>" class="layui-input">
                </div>
            </div>
            <div class="form-group">
                <label class="col-sm-2 control-label">手机号</label>
                <div class='col-sm-8'>
                    <input type="text" name="company_head_mobile"  placeholder="手机号" value="<?php echo sysconf('company_head_mobile'); ?>" class="layui-input">
                </div>
            </div>
        </div>
        </div>
     </div>
    <div class="hr-line-dashed"></div>

    <div class="col-sm-4 col-sm-offset-2">
        <div class="layui-form-item text-center">
            <button class="layui-btn" type="submit">保存配置</button>
        </div>
    </div>

</form>

    </div>
    
<script>
    layui.use('element', function(){
        var element = layui.element();

        //…
    });
    $(function () {
        $('[name="storage_type"]').on('change', function () {
            $("[data-storage-type]").not($("[data-storage-type='" + $(this).val() + "']").show()).hide();
        }).trigger('change');
    });
</script>

</div>